# -*- coding: utf-8 -*-
"""
Created on Tue Jun 30 11:01:49 2020

@author: David Loor
"""

def mensaje ():
    print("Ingrese el numero para la operacion")    
#print("Ingrese el numero ")
mensaje()
a=int(input())
#print("Ingrese el numero ")
mensaje()
b=int(input())
#print("Ingrese el numero ")
mensaje()
c=int(input())
#print("Ingrese el numero ")
mensaje()
d=int(input())

def hola(nombre):
    print("Hola "+ nombre+"\n")
hola("David")
hola("Manolo")


def holatodos(nombre1, nombre2):
    print("Hola "+ nombre1+"\n")
    print("Hola "+ nombre2+"\n")
holatodos("Manolo", "Arturito")
holatodos("Crisian", "Saul")


def direccion(calle,sector,codigopostal, referencia, numcasa):
    print("Su sector es "+ sector +"\n"+
          "Su calle el "+ calle +"\n"+
          "Su numero de casa es "+ numcasa +"\n"+
          "con codigo postal "+ codigopostal +"\n"+
          "Con referencia "+ referencia)
print("Ingrese los datos de direccion")
calle=input("Ingrese la calle"+"\n")
sector=input("Ingrese su sector"+"\n")
codigopostal=input("Ingrese codigo postal"+"\n")
referencia=input("Ingrese una referencia"+"\n")
numcasa=input("Ingrese el numero de su casa"+"\n")
direccion(calle, sector, codigopostal, referencia, numcasa)


def resta(a,b):
    print("El resultado de la resta entre ", a ," y ", b ," Es igual a ", a-b , "\n")
resta(5,2)
resta(2,5)
resta(a=8,b=2)
resta(a=2,b=8)
resta(3,b=1)
#resta(a=2,3) error de argumento pocisional


def multiplicacion(a,b):
    print("El resultado de la multiplicacion es ", a*b, "\n")
    return(a*b)
multiplicacion(4, 5)
print("El resultado es ",multiplicacion(4, 5))  


def holatodos(lista):
    for a in lista:
        print("Hola ",a,"\n")
holatodos(["David","Brayan","Manolo"])
holatodos(["Manuel","Samuel","Annuel"])  


def listacreada(n):
    lista1=[]
    for i in range(n):
        lista1.append(i)
    return lista1
print(listacreada(5)) 