# -*- coding: utf-8 -*-
"""
Created on Thu Jun 25 14:36:42 2020

@author: David Loor
"""


horas=input("Horas trabajadas"+"\n")
horas=int(horas)
tarifa=input("Tarifa por hora"+"\n")
tarifa=int(tarifa)
descuentos=input("Descuentos"+"\n")
descuentos=int(descuentos)
if horas<40:
    paga=horas*tarifa-descuentos
    paga=str(paga)
    print("Valor a pagar es de "+paga)
else:
    pasadas=horas-40
    bono=pasadas*0.50
    horas=horas+bono
    paga=(horas*tarifa)-descuentos
    paga=str(paga)
    print("Valor a pagar es de "+paga)