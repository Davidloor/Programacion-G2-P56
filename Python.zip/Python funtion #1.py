# -*- coding: utf-8 -*-
"""
Created on Thu Jul  2 18:52:14 2020

@author: David loor
"""

yr1=int(input("Ingrese un año"+"\n"))
yr2=int(input("Ingrese un año"+"\n"))
yr3=int(input("Ingrese un año"+"\n"))
yr4=int(input("Ingrese un año"+"\n"))
def bisiesto(y):
    if y % 400 == 0:
        return True
    elif y % 100 == 0:
        return False
    elif y % 4 == 0:
        return True
    else:
        return False
bisiesto(yr1)
bisiesto(yr2)
bisiesto(yr3)
bisiesto(yr4)

lista1=[]
lista1.append(yr1)
lista1.append(yr2)
lista1.append(yr3)
lista1.append(yr4)
print(lista1)

lista2=[]
lista2.append(bisiesto(yr1))
lista2.append(bisiesto(yr2))
lista2.append(bisiesto(yr3))
lista2.append(bisiesto(yr4))
print(lista2)
