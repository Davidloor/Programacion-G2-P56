# -*- coding: utf-8 -*-
"""
Created on Tue Jul 14 11:30:46 2020

@author: David loor
"""

import numpy as np
matriz=np.array([(3,2,1,0),(6,5,4,3)])
print(matriz)
print(matriz[1,2])
print(matriz[0,0])
print(matriz[0,1])
print(matriz[0,2])
print(matriz[0,3])
