# -*- coding: utf-8 -*-
"""
Created on Thu Jul  9 14:44:34 2020

@author: HP
"""


import fibonacci
fibonacci.fibonacci(100)