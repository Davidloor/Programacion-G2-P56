# -*- coding: utf-8 -*-
"""
Created on Thu Jul  9 13:33:24 2020

@author: David Loor
"""


def fibonacci(n):
    a=0
    b=1
    while a<=n:
        print(a,end=" ")
        a,b=b,a+b
fibonacci(8)