# -*- coding: utf-8 -*-
"""
Created on Thu Jun 25 15:06:28 2020

@author: David Loor
"""


n1=input("Ingrese su primera nota"+"\n")
n1=int(n1)
n2=input("Igrese su segunda nota"+"\n")
n2=int(n2)
n3=input("Ingrese su tercera nota"+"\n")
n3=int(n3)
suma1=n1+n2
suma2=n2+n3
suma3=n3+n1
if suma1>suma2:
    suma1=str(suma1)
    print("Su calificacion total es "+ suma1)
elif suma2>suma3:
    suma2=str(suma2)
    print("Su calificacion total es "+ suma2)
else:
    suma3=str(suma3)
    print("Su calificacion total es "+ suma3)