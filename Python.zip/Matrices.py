# -*- coding: utf-8 -*-
"""
Created on Fri Jul 10 12:07:58 2020

@author: David Loor
"""


import numpy as np
matrix=np.array([[1,2,3,4,5],[6,7,8,9,10]],dtype=np.int64)
print(matrix,"\n")

unos=np.ones((8,4))
print(unos,"\n")

unos=np.zeros((8,4))
print(unos,"\n")

ran=np.random.random((4,4))
print(ran,"\n")

ept=np.empty((5,5))
print(ept,"\n")

full=np.full((5,5),10)
print(full,"\n")

esp=np.arange(0,100,5)
print(esp,"\n")