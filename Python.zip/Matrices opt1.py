# -*- coding: utf-8 -*-
"""
Created on Tue Jul 14 11:45:15 2020

@author: David Loor
"""


import numpy as np
matriz=np.array([(3,2,1,0),(6,5,4,3)])
print(matriz,"\n")
print(matriz.min(),"\n")
print(matriz.max(),"\n")
print(matriz.sum(),"\n")
print(matriz.std(),"\n")
print(np.std(matriz),"\n")
print(np.sqrt(matriz),"\n")
