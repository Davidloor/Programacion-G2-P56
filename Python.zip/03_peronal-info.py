# -*- coding: utf-8 -*-
"""
Created on Fri Jun 19 12:20:31 2020

@author: David Loor
"""


nombre=input("¿Me podrias decir nombre?"+"\n")
print("Enserio te llamas "+ nombre) 

apellido=input("¿Y cual es tu apellido?"+"\n")
print("Hola como estas "+ nombre + " " + apellido +"!")

vives=input("¿Y puedo saber donde vives?"+"\n")
print("Tu vives en "+ vives + "\n"+"Interesante yo no conosco")

edad=input("¿Cuanto años tienes?"+"\n")
print("De verdad tienes "+ edad +" años")

print("Entonses te llamas "+nombre+" "+apellido+", vives en "+vives+" y tienes "+edad+" años")

edad=int(edad)
if(edad>=0 and edad<=13):
    print("Eres aun un niño")
elif(edad>=14 and edad<=28):
    print("Eres ya un joven")
elif(edad>=29 and edad<=50):
    print("Ya eres un adulto")
else:
    print("Eres un adulto mayor")
    