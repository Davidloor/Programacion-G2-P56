# -*- coding: utf-8 -*-
"""
Created on Mon Jul 20 17:06:12 2020

@author: David Loor
"""

clave=4
while clave==4:
    tamanovector=input("EL tamaño del vector debe ser mayor a 3 y menor a 30"+"\n")
    tamanovector=int(tamanovector)
    while (tamanovector<3 or tamanovector>30):
        tamanovector=input("EL tamaño del vector debe ser mayor a 3 y menor a 30"+"\n")
        tamanovector=int(tamanovector)
        if (tamanovector>3 and tamanovector<30):
            break
        else:
            continue
    print("Debe elegir entre caracter o numero","\n",
          "Eliga 1---> Numero","\n",
          "Eliga 2---> Caracteres")
    e=int(input())
    if e==1:
        print("Elegiste ordenar numero","\n",
              "Eliga 7---> De Menor a Mayor","\n",
              "Eliga 8---> De Mayor a Menor")
        d=int(input())
        if d==7:
            from random import randint
            from time import sleep
            auxiliar=int()
            vector=[int() for ind0 in range(100)]
            for i in range(1,tamanovector+1):
                vector[i-1]= randint(0,99)
                print("El valor en la posicion",i,"es",vector[i-1])
                sleep(1)
                sleep(1)
            for j in range(1,tamanovector+1):
                for l in range(1,tamanovector):
                    if vector[l-1]>vector[l]:
                        auxiliar = vector[l-1]
                        vector[l-1] = vector[l]
                        vector[l] = auxiliar
            for k in range(1,tamanovector+1):
                print("El vector ordenado en la posicion",k,"es",vector[k-1])
                sleep(1)
        else:
            from random import randint
            from time import sleep
            auxiliar = int()
            vector = [int() for ind0 in range(100)]
            for i in range(1,tamanovector+1):
                vector[i-1] =randint(0,99)
                print("El valor en la pocision",i,"es",vector[i-1])
                sleep(1)
            sleep(1)
            for j in range(1,tamanovector+1):
                for l in range(1,tamanovector):
                    if vector[l-1]<vector[l]:
                        auxiliar=vector[l-1]
                        vector[l-1]=vector [l]
                        vector[l]=auxiliar
            for k in range(1,tamanovector+1):
                print("El vector ordenado en la posicion",k,"es",vector[k-1])
                sleep(1)
    else:
        auxiliar=str()
        nombre=str()
        vector=[str()for ind0 in range (100)]
        for i in range (1,tamanovector+1):
            print("Ingrese el nombre del estudiante",i)
            nombre=input()
            vector[i-1]= nombre
            print("El valor de la pocision",i,"es",vector[i-1])
        for j in range(1,tamanovector+1):
            for l in range(1,tamanovector):
                if vector[l-1]>vector[l]:
                    auxiliar= vector[l-1]
                    vector[l-1]= vector[l]
                    vector[l]= auxiliar
        for k in range(1,tamanovector+1):
            print("El vector ordenado en la posicion",k,"es",vector[k-1])
    print("Desea finalizar","\n",
      "Digite 4 ---> Continuar","\n",
      "Digite 5 ---> Finalizar")
    clave=int(input())