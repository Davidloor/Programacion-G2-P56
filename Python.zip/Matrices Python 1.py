# -*- coding: utf-8 -*-
"""
Created on Tue Jul 14 12:16:25 2020

@author: David Loor
"""

matriz=[[0,0,0,0,0,0],[0,0,0,0,0,0],
        [0,0,0,0,0,0],[0,0,0,0,0,0],
        [0,0,0,0,0,0]]

for i in range (0,5):
   for j in range (0,6):
       print("Ingrese el valor para la posicion:",i,j)
       matriz[i][j]=int(input())
print(matriz)
       