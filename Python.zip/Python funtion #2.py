# -*- coding: utf-8 -*-
"""
Created on Thu Jul  2 20:44:23 2020

@author: David Loor
"""

yr1=int(input("Ingrese un año"+"\n"))
yr2=int(input("Ingrese un año"+"\n"))
yr3=int(input("Ingrese un año"+"\n"))
yr4=int(input("Ingrese un año"+"\n"))
def bisiesto(y):
    if y % 400 == 0:
        return True
    elif y % 100 == 0:
        return False
    elif y % 4 == 0:
        return True
    else:
        return False
bisiesto(yr1)
bisiesto(yr2)
bisiesto(yr3)
bisiesto(yr4)

lista1=[]
lista1.append(yr1)
lista1.append(yr2)
lista1.append(yr3)
lista1.append(yr4)
print(lista1)

lista2=[]
lista2.append(bisiesto(yr1))
lista2.append(bisiesto(yr2))
lista2.append(bisiesto(yr3))
lista2.append(bisiesto(yr4))
print(lista2)

m1=input("Ingrese un mes en numeros"+"\n")
m2=input("Ingrese un mes en numeros"+"\n")
m3=input("Ingrese un mes en numeros"+"\n")
m4=input("Ingrese un mes en numeros"+"\n")
def diames(y, m):
    if m in("1","3","7","8","10","12"):
        return "31"
    elif m in("2"):
        if bisiesto(y) is True:
            return "29"
        else:
            return "28"
    else:
        return "30"
diames(yr1,m1)
diames(yr2,m2)
diames(yr3,m3)
diames(yr4,m4)

lista3=[]
lista3.append(m1)
lista3.append(m2)
lista3.append(m3)
lista3.append(m4)
print(lista3)

lista4=[]
lista4.append(diames(yr1,m1))
lista4.append(diames(yr2,m2))
lista4.append(diames(yr3,m3))
lista4.append(diames(yr4,m4))
print(lista4)

