# -*- coding: utf-8 -*-
"""
Created on Thu Jun 25 14:06:30 2020

@author: David Loor
"""

llantas=input("Cantidad de llantas"+"\n")
llantas=int(llantas)
precio=input("Precio unitario"+"\n")
precio=int(precio)
if llantas<4:
    pagar=llantas*precio
    pagar=str(pagar)
    print("Usted debe pagar "+ pagar)
else:
    descuento=precio*0.90
    pagar=llantas*descuento
    pagar=str(pagar)
    print("Usted debe pagar "+ pagar)