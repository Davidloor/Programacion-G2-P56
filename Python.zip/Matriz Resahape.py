# -*- coding: utf-8 -*-
"""
Created on Tue Jul 14 11:23:51 2020

@author: David Loor
"""


import numpy as np
matrix=np.array([(3,2,1),(6,5,4)])
print(matrix)
matrix=matrix.reshape(3,2)
print(matrix)