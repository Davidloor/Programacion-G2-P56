# -*- coding: utf-8 -*-
"""
Created on Fri Jun 26 11:33:52 2020

@author: David Loor
"""


datos=input("Ingrese el numero de veces que contare: "+"\n")
datos=int(datos)
contador=1
acumulador=0
while contador<=datos:
    print(contador,end=" ")
    acumulador=acumulador+contador
    contador=contador+1
print("\n"*1)
print("La suma de los numeros es:", acumulador)
promedio=acumulador/datos
print("El promedio es ", promedio)


datos=input("Ingrese el numero de veces que contare: "+"\n")
datos=int(datos)
contador=1
acumulador=0
while True:
    print(contador)
    acumulador=acumulador+contador
    contador=contador+1
    if contador>datos:
        break
print("\n"*1)
print("La suma de los numeros es:", acumulador)
promedio=acumulador/datos
print("El promedio es ", promedio)

while True:
    datos=input("Ingrese el numero de veces que contare: "+"\n")
    if datos=="q" or datos=="quit":
        break
    else:
        datos=int(datos)
        contador=1
        while True:
            print(contador)
            contador=contador+1
            if contador>datos:
                break

