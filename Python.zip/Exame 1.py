# -*- coding: utf-8 -*-
"""
Created on Tue Jul 28 11:28:17 2020

@author: HP
"""


blanco_negro=int(0.06)
color = 0.12
a=int(input('Escriba la cantidad de impresiones que habia al iniciar del mes'+"\n"))
b=int(input('Digite el la cantidad de impresiones que hubo al finalizar el mes'+"\n"))
while a>=b:
    print('El numero de impresiones al finalizar el mes debe ser mayor al que inicio el mes')
    a=int(input('Escriba la cantidad de impresiones que habia al iniciar del mes'+"\n"))
    b=int(input('Digite el la cantidad de impresiones que hubo al finalizar el mes'+"\n"))
c=int(input('Digite 1 si quiere imprimir a blanco y negro'+"\n"+
            'Digite 2 si quiere imprimir a color'+"\n"))

if c==1:
    finmes = b-a
    costo=(finmes*0.06)
else:
    finmes = b-a
    costo = finmes*0.12
print('El total de impresiones fueron ',finmes)
print('El costo de todas las impresiones fue ',costo)