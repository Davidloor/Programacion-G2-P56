# -*- coding: utf-8 -*-
"""
Created on Tue Jun 23 11:09:17 2020

@author: David Loor
"""


nativa=1
datos=100
if nativa==datos:
    print("La VLAN nativa")
else:
    print("La VLAN es diferente")

aclnum= int(input("What is the IPv4 ACl number?"))
if aclnum>=1 and aclnum <=99:
    print("This is a standard IPv4 ACL")
elif aclnum>=100 and aclnum <=199:
    print("This is a extended IPv4 ACL")
else:
    print("This is not a satandar or extended IPv4 ACL")
    
