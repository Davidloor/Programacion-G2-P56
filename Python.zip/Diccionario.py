# -*- coding: utf-8 -*-
"""
Created on Fri Jun 19 11:05:52 2020

@author: David Loor
"""


ipaddress={ "R1":"10.1.1.1",
           "R2":"10.2.2.1",
           "R3":"10.3.3.1",
           "S1":"10.1.0.1"}
print(type(ipaddress))

dict1={"usuario":"1726448077",
       "valor":"5000",
       "edad":"18",
       "casado":False,
       "rate en %":52.2}
print(type(dict1))

print(dict1["usuario"])
dict1["Sexo"]="Hombre"
print("valor" in dict1)