# -*- coding: utf-8 -*-
"""
Created on Tue Jun 23 12:24:59 2020

@author: David Loor
"""


devices=["R1","R2","R3","S1","S2"]
for item in devices:
    if "R" in devices:
        print(item)

result=0
n=5
for i in range (1,n+1):
    print(i)
    result=result+i
print("El resultado de la suma de 1 hasta n es: ", result)
    
for i in range(10,0,-1):
    print(i)
    
for i in "AMIGO":
    print("Dame una ",{i})
print("AMIGO")

print("Comienzo")
for i in range(3):
   print("Hola ", end="") 
print()
print("Final")

router=[]
switch=[]
lista=["R1","R2","R3","S1","S2"]
for i in lista:
    if "S" in i:
        switch.append(i)   
    else:
        router.append(i)
print(switch)
print(router)