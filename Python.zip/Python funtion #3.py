# -*- coding: utf-8 -*-
"""
Created on Thu Jul  2 21:25:44 2020

@author: David Loor
"""

yr1=int(input("Ingrese un año"+"\n"))
def bisiesto(y):
    if y % 400 == 0:
        return True
    elif y % 100 == 0:
        return False
    elif y % 4 == 0:
        return True
    else:
        return False
bisiesto(yr1)
print("El año ",yr1," es un año bisiesto?", bisiesto(yr1))
      
m1=str(input("Ingrese un mes en numeros"+"\n"))
def diames(y, m):
    if m in("1","3","7","8","10","12"):
        return "31"
    elif m in "2":
        if bisiesto(y) is True:
            return "29"
        else:
            return "28"
    else:
        return "30"
diames(yr1,m1)
print("El mes numero ",m1," del año ",yr1," tiene ",diames(yr1, m1))

d1=int(input("Ingrese un dia"+"\n"))
s=0
enero=31
febrero=28
febrerob=29
marzo=31
abril=30
mayo=31
junio=30
julio=31
agosto=31
septiembre=30
octubre=31
noviembre=30
diciembre=31
def fecha(y,m,d):
    if m in "1":
        return d1
    elif m in "2":
        return enero+d1
    elif m in "3":
        if bisiesto(y) is True:
            return enero+febrerob+d1
        else:
            return enero+febrero+d1
    elif m in "4":
        if bisiesto(y) is True:
            return enero+febrerob+marzo+d1
        else:
            return enero+febrero+marzo+d1
    elif m in "5":
        if bisiesto(y) is True:
            return enero+febrerob+marzo+abril+d1
        else:
            return enero+febrero+marzo+abril+d1
    elif m in "6":
        if bisiesto(y) is True:
            return enero+febrerob+marzo+abril+mayo+d1
        else:
            return enero+febrero+marzo+abril+mayo+d1
    elif m in "7":
        if bisiesto(y) is True:
            return enero+febrerob+marzo+abril+mayo+junio+d1
        else:
            return enero+febrero+marzo+abril+mayo+junio+d1
    elif m in "8":
        if bisiesto(y) is True:
            return enero+febrerob+marzo+abril+mayo+junio+julio+d1
        else:
            return enero+febrero+marzo+abril+mayo+junio+julio+d1
    elif m in "9":
        if bisiesto(y) is True:
            return enero+febrerob+marzo+abril+mayo+junio+julio+agosto+d1
        else:
            return enero+febrero+marzo+abril+mayo+junio+julio+agosto+d1
    elif m in "10":
        if bisiesto(y) is True:
            return enero+febrerob+marzo+abril+mayo+junio+julio+agosto+septiembre+d1
        else:
            return enero+febrero+marzo+abril+mayo+junio+julio+agosto+septiembre+d1
    elif m in "11":
        if bisiesto(y) is True:
            return enero+febrerob+marzo+abril+mayo+junio+julio+agosto+septiembre+octubre+d1
        else:
            return enero+febrero+marzo+abril+mayo+junio+julio+agosto+septiembre+octubre+d1
    else:
        if bisiesto(y) is True:
            return enero+febrerob+marzo+abril+mayo+junio+julio+agosto+septiembre+octubre+noviembre+d1
        else:
            return enero+febrero+marzo+abril+mayo+junio+julio+agosto+septiembre+octubre+noviembre+d1

fecha(yr1,m1,d1)
lista=[]
lista.append(yr1)
lista.append(m1)
lista.append(d1)
print("La fecha introducida es ",lista)
print("Desde el primer dia del año han pasado", fecha(yr1, m1, d1))