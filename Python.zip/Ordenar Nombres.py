# -*- coding: utf-8 -*-
"""
Created on Fri Jul 17 12:23:22 2020

@author: David Loor
"""


auxiliar=str()
nombre=str()
vector=[str()for ind0 in range (100)]
print("Ingrese el tamaño del vector")
tamañovector= int(input())
for i in range (1,tamañovector+1):
    print("Ingrese el nombre del estudiante",i)
    nombre=input()
    vector[i-1]= nombre
    print("El valor de la pocision",i,"es",vector[i-1])
for j in range(1,tamañovector+1):
    for l in range(1,tamañovector):
        if vector[l-1]>vector[l]:
            auxiliar= vector[l-1]
            vector[l-1]= vector[l]
            vector[l]= auxiliar
for k in range(1,tamañovector+1):
    print("El vector ordenado en la posicion",k,"es",vector[k-1])