# -*- coding: utf-8 -*-
"""
Created on Tue Jul  7 12:28:26 2020

@author: HP
"""


from math import ceil,floor,trunc

x=1.4
y=2.6

print(floor(x),floor(y))
print(floor(-x),floor(-y))
print(ceil(x),ceil(y))
print(ceil(-x),ceil(y))
print(trunc(x),trunc(y))
print(trunc(-x),trunc(-y))
