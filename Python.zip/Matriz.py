# -*- coding: utf-8 -*-
"""
Created on Tue Jul 14 10:23:58 2020

@author: David Loor
"""


import numpy as np
a=np.array([(1,2,3),(4,5,6)],dtype=np.int64)
print(a)
print("La matriz tiene:",a.ndim,"dimensiones")
print("El tipo de dato es:",a.dtype)
print("El tamaño de la matriz es:",a.size)
print("La forma de la matriz es:",a.shape)
