# -*- coding: utf-8 -*-
"""
Created on Tue Jun 23 12:45:45 2020

@author: David Loor
"""
print ("Hello World!")
print ("Hola mundo desde la UPS")



