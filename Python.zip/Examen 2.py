# -*- coding: utf-8 -*-
"""
Created on Tue Jul 28 10:53:31 2020

@author: David Loor
"""


print("-ANALISIS DE TEMPERATURAS-")
datos=int(input("Ingrese cantidad de temperaturas [1,10]"+"\n"))
while datos<1 or datos>10:
    datos=int(input("Ingrese cantidad de temperaturas [1,10]"+"\n"))
    
a=0
b=0
c=0
x=0
for i in range (1,datos+1):

    print("Temperatura",i,"en °C:",end="")
    x=int(input())
    
    if x>=100:
        a=a+1
    elif x>0 and x<100:
        b=b+1
    elif x<=0:
        c=c+1
    
print("Cantidad de muestras gaseosa:",a)
print("Cantidad de muestras liquidas:",b)
print("Cantidad de muestras solida:",c)
