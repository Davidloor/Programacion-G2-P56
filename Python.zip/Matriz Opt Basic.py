# -*- coding: utf-8 -*-
"""
Created on Tue Jul 14 11:55:16 2020

@author: David Loor
"""


import numpy as np
a=np.array([(1,2,3),(4,5,6)])
b=np.array([(1,2,3),(4,5,6)])
print(a+b,"\n")
print(a-b,"\n")
print(a*b,"\n")
print(a/b,"\n")
