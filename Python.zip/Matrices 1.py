# -*- coding: utf-8 -*-
"""
Created on Fri Jul 10 11:24:46 2020

@author: David Loor
"""

import numpy as np

a=np.array([1,2,3])
print(a)

b=np.array([(1,2,3),(4,5,6)])
print(b)

